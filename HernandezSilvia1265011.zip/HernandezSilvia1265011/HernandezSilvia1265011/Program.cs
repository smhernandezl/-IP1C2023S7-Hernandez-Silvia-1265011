﻿// See https://aka.ms/new-console-template for more information

//Calculadora

/*
 Analisis
    - Operadores
       - Aritmeticos (suma, resta, multiplicacion, division)
    - Valores
       - Ingresados por el usuario
       - Mostrarlos y almacenarlos
            - 5 valores numericos a almacenar + el resultado
       - Operarlos
    - Mostrar el resultado
    - Preguntarle al usuario si quiere operar otros numeros
    - Definir cantidad maxima de numeros de ingresar y operar
    - Cuantas operaciones quiere hacer
         - 1 operacion de cada tipo por ecuacion
                - Ej: 4x5+15/20-10
                - (4x5+15)/(20-10)
                    (20+15)/10
                        35/10
                           
                    (4x5)+(15/20)-10
    - Borrar
    - Manejo de errores
    - Manejo de suma sobre el ultimo valor resultante

 */
//Tipos de datos - Declaracion de variables
double _numeroA, _numeroB, _numeroC, _numeroD, _numeroE, _resultado;


Console.WriteLine("CALCULADORA"); // Para escribir lineas en pantalla
Console.WriteLine("La calculadora resuelve operaciones del siguiente tipo: " +
    "(numeroUno x numeroDos + numeroTres)/(numeroCuatro-numeroCinco). " +
    "Usted debera de ingresar los numeros para operar");


//Obtener valores
Console.WriteLine("Ingrese el primer numero");
string _aux = Console.ReadLine(); //capturando lo ingresado por el usario

    if ( _aux != "") //validar que no este vacio
    {
        _numeroA = double.Parse(_aux); //convertir a decimal y asignar
    }
    else
    {
        _numeroA = 0.0;
    }

Console.WriteLine("Ingrese el segundo numero");
_numeroB = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Ingrese el tercer numero");
_numeroC = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Ingrese el cuarto numero");
_numeroD = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Ingrese el quinto numero");
_numeroE = Convert.ToDouble(Console.ReadLine());

//Operar (4x5+15)/(20-10)

_resultado = ((_numeroA * _numeroB) + _numeroC) / (_numeroD - _numeroE);

Console.WriteLine("El resultado de la operacion es: " + _resultado);

Console.WriteLine("Quiere autosumar su resultado? Si / No");
string sAutosumar = Console.ReadLine().ToLower();

if (sAutosumar == "si")
{
    for (int i = 0; i < 10; i++)
    {
        _resultado = _resultado + _resultado;
    }
}
else
{
    Console.WriteLine("Si desea finalizar ingrese una tecla");

}


Console.ReadLine();//instruccion que espera un caracter ingresado por el usuario desde una terminal 

